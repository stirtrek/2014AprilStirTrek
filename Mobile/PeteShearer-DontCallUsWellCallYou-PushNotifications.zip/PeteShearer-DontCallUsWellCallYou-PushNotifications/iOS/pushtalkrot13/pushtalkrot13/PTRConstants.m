//
//  PTRConstants.m
//  pushtalkrot13
//
//  Created by Peter Shearer on 4/7/14.
//  Copyright (c) 2014 Peter Shearer. All rights reserved.
//

#import "PTRConstants.h"

@implementation PTRConstants

+(NSString *) getAuthorizationAdminEndpoint {
    return @"YOUR_SERVICE_URL";
}

@end
