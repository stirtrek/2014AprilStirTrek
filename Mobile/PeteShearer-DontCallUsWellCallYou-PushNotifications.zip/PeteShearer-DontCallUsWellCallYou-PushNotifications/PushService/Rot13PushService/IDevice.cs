﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Rot13PushService
{
    [ServiceContract]
    public interface IDevice
    {
        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "add/?deviceId={deviceId}&deviceOs={deviceOs}", BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        bool Add(string deviceId, string deviceOs);

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "send/?message={message}", BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        bool SendAllNative(string message);
    }
}
