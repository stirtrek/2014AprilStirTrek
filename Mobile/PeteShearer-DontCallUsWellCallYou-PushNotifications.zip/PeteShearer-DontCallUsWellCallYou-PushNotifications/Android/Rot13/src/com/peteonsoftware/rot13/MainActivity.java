package com.peteonsoftware.rot13;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.net.Uri;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	String TAG = "PushDemo";
	public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String BASE_SERVICE_URL = "Your Service Url";
	
	String SENDER_ID = "Google Project Number from Dashboard"; // Our Project Number
	AtomicInteger msgId = new AtomicInteger();
	GoogleCloudMessaging gcm;
	Context context;
	String regId;
	
	Button _cipherButton;
	Button _pushButton;
	EditText _plainText;
	TextView _cipherText;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        
        // if no Google Play Services, we can't go on
        if (checkPlayServices()) {
	        gcm = GoogleCloudMessaging.getInstance(this);
	        regId = getRegistrationId(context);
	        
	        if (regId.isEmpty()) {
	        	registerInBackground();
	        }
	        else {
	        	Log.i(TAG, regId);
	        }
	        
	        new RegisterDeviceTask().execute();
        } else {
        	Log.i(TAG, "No valid Google Play Services APK found");
        }
        
        _cipherButton = (Button)this.findViewById(R.id.cipher_button);
        _pushButton = (Button)this.findViewById(R.id.push_button);
        _plainText = (EditText)this.findViewById(R.id.plain_text);
        _cipherText = (TextView)this.findViewById(R.id.cipher_text);
        
        _cipherButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                _cipherText.setText(rot13(_plainText.getText().toString()));
            }
        });
        
        _pushButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                new SendPushTask().execute();
            }
        });
        
        onNewIntent(getIntent());
    }
    
    @Override
    public void onNewIntent(Intent intent){
        Bundle extras = intent.getExtras();
        if(extras != null){
        	String pushMessage = extras.getString("PushMessage", "");
            if (pushMessage.length() > 0) {
            	_plainText.setText(pushMessage);
            	_cipherText.setText(rot13(_plainText.getText().toString()));
            }
            	
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    // from http://stackoverflow.com/questions/8981296/rot-13-function-in-java
    private String rot13(String input) {
    	   StringBuilder sb = new StringBuilder();
    	   for (int i = 0; i < input.length(); i++) {
    	       char c = input.charAt(i);
    	       if       (c >= 'a' && c <= 'm') c += 13;
    	       else if  (c >= 'A' && c <= 'M') c += 13;
    	       else if  (c >= 'n' && c <= 'z') c -= 13;
    	       else if  (c >= 'N' && c <= 'Z') c -= 13;
    	       sb.append(c);
    	   }
    	   return sb.toString();
    }
    
    private class RegisterDeviceTask extends AsyncTask<Void, Void, String> {

		String URL = String.format("%s/device/add/?deviceId=%s&deviceOs=ANDROID", 
				BASE_SERVICE_URL, regId);

		AndroidHttpClient mClient = AndroidHttpClient.newInstance("");

		@Override
		protected String doInBackground(Void... params) {

			HttpGet request = new HttpGet(URL);
			ResponseHandler<String> responseHandler = new BasicResponseHandler();

			try {

				return mClient.execute(request, responseHandler);

			} catch (ClientProtocolException exception) {
				exception.printStackTrace();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {

			if (null != mClient)
				mClient.close();

			Log.i(TAG, result);

		}
	}
    
    private class SendPushTask extends AsyncTask<Void, Void, String> {

		String encodedMessage = Uri.encode(_cipherText.getText().toString());
    	String URL = String.format("%s/device/send/?message=%s",
    			BASE_SERVICE_URL, encodedMessage);

		AndroidHttpClient mClient = AndroidHttpClient.newInstance("");

		@Override
		protected String doInBackground(Void... params) {

			HttpGet request = new HttpGet(URL);
			ResponseHandler<String> responseHandler = new BasicResponseHandler();

			try {

				return mClient.execute(request, responseHandler);

			} catch (ClientProtocolException exception) {
				exception.printStackTrace();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {

			if (null != mClient)
				mClient.close();

			Log.i(TAG, result);

		}
	}
    
    
    private String getRegistrationId(Context context) {
        
    	final SharedPreferences prefs = getGcmPreferences(context);
    	
        String registrationId = prefs.getString(PROPERTY_REG_ID, "");
        if (registrationId.isEmpty()) {
            Log.i(TAG, "Registration not found.");
            return "";
        }
        
        // Check if app was updated; if so, it must clear the registration ID
        // since the existing regID is not guaranteed to work with the new
        // app version.
        int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
        int currentVersion = getAppVersion(context);
        if (registeredVersion != currentVersion) {
            Log.i(TAG, "App version changed.");
            return "";
        }
        return registrationId;
    }
    
    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (NameNotFoundException e) {
            throw new RuntimeException("Could not get package name: " + e);
        }
    }
    
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }
    
    private void registerInBackground() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    if (gcm == null) {
                        gcm = GoogleCloudMessaging.getInstance(context);
                    }
                    regId = gcm.register(SENDER_ID);
                    msg = "Device registered, registration ID=" + regId;

                                        // For this demo: we don't need to send it because the device will send
                    // upstream messages to a server that echo back the message using the
                    // 'from' address in the message.

                    // Persist the regID - no need to register again.
                    storeRegistrationId(context, regId);
                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                    // If there is an error, don't just keep trying to register.
                    // Require the user to click a button again, or perform
                    // exponential back-off.
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.i(TAG,  msg);
            }
        }.execute(null, null, null);
    }

    
    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getGcmPreferences(context);
        int appVersion = getAppVersion(context);
        Log.i(TAG, "Saving regId on app version " + appVersion);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PROPERTY_REG_ID, regId);
        editor.putInt(PROPERTY_APP_VERSION, appVersion);
        editor.commit();
    }
    
    private SharedPreferences getGcmPreferences(Context context) {
        // This sample app persists the registration ID in shared preferences, but
        // how you store the regID in your app is up to you.
        return getSharedPreferences(MainActivity.class.getSimpleName(), Context.MODE_PRIVATE);
    }
}
