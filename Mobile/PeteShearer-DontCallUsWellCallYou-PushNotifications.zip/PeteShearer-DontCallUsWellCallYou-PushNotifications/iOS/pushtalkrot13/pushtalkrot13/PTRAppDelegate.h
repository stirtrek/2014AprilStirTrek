//
//  PTRAppDelegate.h
//  pushtalkrot13
//
//  Created by Peter Shearer on 3/22/14.
//  Copyright (c) 2014 Peter Shearer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PTRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
