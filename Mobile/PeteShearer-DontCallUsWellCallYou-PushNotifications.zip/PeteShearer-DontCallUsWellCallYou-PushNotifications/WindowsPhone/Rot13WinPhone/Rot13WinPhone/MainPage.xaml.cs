﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Rot13WinPhone.Resources;
using System.IO;
using Microsoft.Phone.Notification;

namespace Rot13WinPhone
{
    public partial class MainPage : PhoneApplicationPage
    {
        const string BASE_SERVICE_ENDPOINT = "Your Endpoint Here";

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            /// Holds the push channel that is created or found.
            HttpNotificationChannel pushChannel;

            // The name of our push channel.
            string channelName = "Rot13Channel";

            InitializeComponent();

            // Try to find the push channel.
            pushChannel = HttpNotificationChannel.Find(channelName);

            // If the channel was not found, then create a new connection to the push service.
            if (pushChannel == null)
            {
                pushChannel = new HttpNotificationChannel(channelName);

                // Register for all the events before attempting to open the channel.
                pushChannel.ChannelUriUpdated += new EventHandler<NotificationChannelUriEventArgs>(PushChannel_ChannelUriUpdated);
                pushChannel.ErrorOccurred += new EventHandler<NotificationChannelErrorEventArgs>(PushChannel_ErrorOccurred);

                pushChannel.ShellToastNotificationReceived += new EventHandler<NotificationEventArgs>(PushChannel_ShellToastNotificationReceived);

                pushChannel.Open();


                // Bind this new channel for Toast events.
                pushChannel.BindToShellToast();


            }
            else
            {
                // The channel was already open, so just register for all the events.
                pushChannel.ChannelUriUpdated += new EventHandler<NotificationChannelUriEventArgs>(PushChannel_ChannelUriUpdated);
                pushChannel.ErrorOccurred += new EventHandler<NotificationChannelErrorEventArgs>(PushChannel_ErrorOccurred);
                pushChannel.ShellToastNotificationReceived += new EventHandler<NotificationEventArgs>(PushChannel_ShellToastNotificationReceived);

                // Display the URI for testing purposes. Normally, the URI would be passed back to your web service at this point.
                System.Diagnostics.Debug.WriteLine(pushChannel.ChannelUri.ToString());
                registerDeviceForPush(pushChannel.ChannelUri.ToString());
            }
        }

        void PushChannel_ShellToastNotificationReceived(object sender, NotificationEventArgs e)
        {
            var message = new StringBuilder();
            var relativeUri = string.Empty;
            var receivedMessage = string.Empty;

            message.AppendFormat("Received Toast {0}:\n", DateTime.Now.ToShortTimeString());

            if (e.Collection.ContainsKey("wp:Param"))
            {
                relativeUri = e.Collection["wp:Param"];
            }

            if (e.Collection.ContainsKey("wp:Text1"))
            {
                receivedMessage = e.Collection["wp:Text1"];
            }

            Dispatcher.BeginInvoke(() =>
                {
                    txtPlainText.Text = receivedMessage;
                    txtCipherText.Text = rot13(txtPlainText.Text);
                });
        }

        void PushChannel_ChannelUriUpdated(object sender, NotificationChannelUriEventArgs e)
        {

            Dispatcher.BeginInvoke(() =>
            {
                // Display the new URI for testing purposes. Normally, the URI would be passed back to your web service at this point.
                System.Diagnostics.Debug.WriteLine(e.ChannelUri.ToString());
                registerDeviceForPush(e.ChannelUri.ToString());
            });
        }

        void PushChannel_ErrorOccurred(object sender, NotificationChannelErrorEventArgs e)
        {
            // Error handling logic for your particular application would be here.
            Dispatcher.BeginInvoke(() =>
                MessageBox.Show(String.Format("A push notification {0} error occurred.  {1} ({2}) {3}",
                    e.ErrorType, e.Message, e.ErrorCode, e.ErrorAdditionalData))
                    );
        }

        protected void btnCipher_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPlainText.Text))
            {
                txtCipherText.Text = rot13(txtPlainText.Text);
            }
        }

        // from http://www.dotnetperls.com/rot13
        protected string rot13(string input)
        {
            char[] array = input.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                int number = (int)array[i];

                if (number >= 'a' && number <= 'z')
                {
                    if (number > 'm')
                    {
                        number -= 13;
                    }
                    else
                    {
                        number += 13;
                    }
                }
                else if (number >= 'A' && number <= 'Z')
                {
                    if (number > 'M')
                    {
                        number -= 13;
                    }
                    else
                    {
                        number += 13;
                    }
                }
                array[i] = (char)number;
            }
            return new string(array);
        }

        protected void btnPush_Click(object sender, RoutedEventArgs e)
        {
            var cipherText = txtCipherText.Text;
            if (!string.IsNullOrEmpty(cipherText))
            {
                var uri = string.Format("{0}/device/send/?message={1}", BASE_SERVICE_ENDPOINT, Uri.EscapeUriString(cipherText));
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
                request.BeginGetResponse(pushMessageCallback, request);
            }
        }

        protected void pushMessageCallback(IAsyncResult result)
        {
            HttpWebRequest request = result.AsyncState as HttpWebRequest;
            if (request != null)
            {
                try
                {
                    WebResponse response = request.EndGetResponse(result);
                    var responseStream = response.GetResponseStream();
                    var streamReader = new StreamReader(responseStream);
                    var resultText = streamReader.ReadToEnd();
                    var success = false;
                    bool.TryParse(resultText, out success);

                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        MessageBox.Show(success ? "Push Successful" : "An unknown error occurred");
                    });                  
                }
                catch (WebException e)
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() =>
                    {
                        MessageBox.Show(string.Format("Error: {0}", e.Message));
                    }); 
                    
                    return;
                }
            }
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            if (this.NavigationContext.QueryString.ContainsKey("PushMessage"))
            {
                var receivedMessage = this.NavigationContext.QueryString["PushMessage"];
                txtPlainText.Text = receivedMessage;
                txtCipherText.Text = rot13(txtPlainText.Text);
            }
        }

        protected void registerDeviceForPush(string identifier)
        {
            var uri = string.Format("{0}/device/add/?deviceId={1}&deviceOs=WINPHONE", BASE_SERVICE_ENDPOINT, Uri.EscapeUriString(identifier));
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
            request.BeginGetResponse(registerDeviceCallback, request);
        }

        protected void registerDeviceCallback(IAsyncResult result)
        {
            HttpWebRequest request = result.AsyncState as HttpWebRequest;
            if (request != null)
            {
                try
                {
                    WebResponse response = request.EndGetResponse(result);
                    var responseStream = response.GetResponseStream();
                    var streamReader = new StreamReader(responseStream);
                    var resultText = streamReader.ReadToEnd();
                    var success = false;
                    bool.TryParse(resultText, out success);

                    System.Diagnostics.Debug.WriteLine(success ? "Register Device Successful" : "An unknown error occurred");
                }
                catch (WebException e)
                {
                    System.Diagnostics.Debug.WriteLine(e.Message);
                }
            }
        }
    }
}