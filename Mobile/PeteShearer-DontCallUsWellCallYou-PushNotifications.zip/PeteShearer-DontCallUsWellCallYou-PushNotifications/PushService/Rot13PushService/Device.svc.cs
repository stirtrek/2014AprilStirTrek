﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Hosting;
using MoonAPNS;
using NLog;

namespace Rot13PushService
{
    public class Device : IDevice
    {
        protected const string IOS = "IOS";
        protected const string ANDROID = "ANDROID";
        protected const string WIN_PHONE = "WINPHONE";
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        protected const string PATH_TO_CERT = "~/Path/To/P12Cert";
        protected const string CERT_PASSWORD = "P12CertPassword";
        protected const string GOOGLE_APP_ID = "Your app id";
        protected const string SENDER_ID = "562732285451";
        protected const string ANDROID_COLLAPSE_KEY = "Your collapse key";

        public bool Add(string deviceId, string deviceOs)
        {
            try
            {
                var repo = new DeviceRepository();
                repo.Add(deviceId, deviceOs);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(LogLevel.Error, ex.Message, ex);
                return false;
            }
        }

        public bool SendAllNative(string message)
        {
            try
            {
                SendAndroidNative(message);
                SendAppleNative(message);
                SendWindowsPhoneNative(message);

                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(LogLevel.Error, ex.Message, ex);
                return false;
            }
        }

        public bool SendAppleNative(string message)
        {
            try
            {
                var certPath = HostingEnvironment.MapPath(PATH_TO_CERT);
                var push = new PushNotification(true, certPath, CERT_PASSWORD);
                var list = new List<NotificationPayload>();

                var repo = new DeviceRepository();

                foreach (var device in repo.List(IOS))
                {
                    list.Add(new NotificationPayload(device.DeviceIdentifier, message, 0));
                }

                var errors = push.SendToApple(list);

                return errors.Count == 0;

            }
            catch (Exception ex)
            {
                Logger.LogException(LogLevel.Error, ex.Message, ex);
                return false;
            }
        }

        public bool SendAndroidNative(string message)
        {
            try
            {
                var repo = new DeviceRepository();
                var devices = repo.List(ANDROID);

                foreach (var device in devices)
                {
                    var deviceId = device.DeviceIdentifier;

                    var webRequest = WebRequest.Create("https://android.googleapis.com/gcm/send");
                    webRequest.Method = "post";
                    webRequest.ContentType = " application/x-www-form-urlencoded;charset=UTF-8";
                    webRequest.Headers.Add(string.Format("Authorization: key={0}", GOOGLE_APP_ID));

                    webRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));

                    var postData = string.Format("collapse_key={0}&data.message={1}&registration_id={2}&alert=some alert", 
                        ANDROID_COLLAPSE_KEY, message, deviceId);

                    var byteArray = Encoding.UTF8.GetBytes(postData);
                    webRequest.ContentLength = byteArray.Length;

                    var dataStream = webRequest.GetRequestStream();
                    dataStream.Write(byteArray, 0, byteArray.Length);
                    dataStream.Close();

                    var webResponse = webRequest.GetResponse();

                    dataStream = webResponse.GetResponseStream();

                    var reader = new StreamReader(dataStream);

                    // for debugging
                    var sResponseFromServer = reader.ReadToEnd();

                    reader.Close();
                    dataStream.Close();
                    webResponse.Close();
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(LogLevel.Error, ex.Message, ex);
                return false;
            }
        }

        public bool SendWindowsPhoneNative(string message)
        {
            try
            {
                var repo = new DeviceRepository();
                var devices = repo.List(WIN_PHONE);

                // Create the toast message.
                var toastMessageRaw = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                    "<wp:Notification xmlns:wp=\"WPNotification\">" +
                       "<wp:Toast>" +
                            "<wp:Text1>{0}</wp:Text1>" +
                            "<wp:Param>/MainPage.xaml?PushMessage={1}</wp:Param>" +
                       "</wp:Toast> " +
                    "</wp:Notification>";

                var toastMessage = string.Format(toastMessageRaw, message, Uri.EscapeUriString(message));

                foreach (var mobileDevice in devices)
                {
                    // For WinPhone, each Device/App combo has a unique URI
                    var subscriptionUri = mobileDevice.DeviceIdentifier;

                    var sendNotificationRequest = (HttpWebRequest)WebRequest.Create(subscriptionUri);
                    sendNotificationRequest.Method = "POST";

                    // The optional custom header X-MessageID uniquely identifies a notification message. 
                    // If it is present, the // same value is returned in the notification response. It must be a string that contains a UUID.
                    // sendNotificationRequest.Headers.Add("X-MessageID", "<UUID>");

                    // Sets the notification payload to send.
                    var notificationMessage = Encoding.Default.GetBytes(toastMessage);

                    // Sets the web request content length.
                    sendNotificationRequest.ContentLength = notificationMessage.Length;
                    sendNotificationRequest.ContentType = "text/xml";
                    sendNotificationRequest.Headers.Add("X-WindowsPhone-Target", "toast");
                    sendNotificationRequest.Headers.Add("X-NotificationClass", "2");


                    using (Stream requestStream = sendNotificationRequest.GetRequestStream())
                    {
                        requestStream.Write(notificationMessage, 0, notificationMessage.Length);
                    }

                    // Send the notification and get the response.
                    var response = (HttpWebResponse)sendNotificationRequest.GetResponse();
                    var notificationStatus = response.Headers["X-NotificationStatus"];
                    var notificationChannelStatus = response.Headers["X-SubscriptionStatus"];
                    var deviceConnectionStatus = response.Headers["X-DeviceConnectionStatus"];

                    // Log the response from the Microsoft Push Notification Service.  
                    Logger.Log(LogLevel.Info, notificationStatus + " | " + deviceConnectionStatus + " | " + notificationChannelStatus);
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(LogLevel.Error, ex.Message, ex);
                return false;
            }
        }
    }
}
