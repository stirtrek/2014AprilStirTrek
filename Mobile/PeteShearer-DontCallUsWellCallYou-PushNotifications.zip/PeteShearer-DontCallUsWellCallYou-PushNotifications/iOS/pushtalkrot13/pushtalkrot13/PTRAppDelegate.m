//
//  PTRAppDelegate.m
//  pushtalkrot13
//
//  Created by Peter Shearer on 3/22/14.
//  Copyright (c) 2014 Peter Shearer. All rights reserved.
//

#import "PTRAppDelegate.h"
#import "PTRViewController.h"
#import <Pushbots/Pushbots.h>
#import "PTRConstants.h"

@implementation PTRAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	// Let the device know we want to receive push notifications
	
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    //[Pushbots getInstance];
    
    NSDictionary *options = [launchOptions objectForKey: UIApplicationLaunchOptionsRemoteNotificationKey];
    
    if (options)
    {
        NSDictionary *aps = options[@"aps"];
        if (aps)
        {
            NSString *message = aps[@"alert"];
            NSLog(@"We got: %@", message);
            
            NSDictionary *info = @{@"PushMessage": message };
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PushReceived"
                                                                object:nil
                                                              userInfo:info];
        }
    }   
    
    
    return YES;
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
	
    NSString *token = [NSString stringWithFormat:@"%@", [deviceToken description]];
    token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
    token = [token stringByReplacingOccurrencesOfString:@"<" withString:@""];
    token = [token stringByReplacingOccurrencesOfString:@">" withString:@""];
    
    NSString *urlBase = @"%@/device/add/?deviceId=%@&deviceOs=IOS";
    NSString *url = [NSString stringWithFormat:urlBase, [PTRConstants getServiceEndpoint], token];
    
    NSLog(@"Our URL: %@", url);
    
    NSURLRequest * urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSURLResponse * response = nil;
    NSError * error = nil;
    NSData * data = [NSURLConnection sendSynchronousRequest:urlRequest
                                          returningResponse:&response
                                                      error:&error];
    
    if (error != nil)
    {
        NSLog(@"Failed to save, error: %@", error);
    }
    else
    {
        NSString *result = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"Registration Worked. We got this back: %@", result);
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSDictionary *aps = userInfo[@"aps"];
    
    if (aps)
    {
        NSString *message = aps[@"alert"];
        NSLog(@"We got: %@", message);
    
        if ( application.applicationState == UIApplicationStateActive )
        {
            // app was already in the foreground
            NSLog(@"Foreground");
        }
        else
        {
            // app was just brought from background to foreground
            NSLog(@"Background");
        }
    
        NSDictionary *info = @{@"PushMessage": message };
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"PushReceived"
                                                            object:nil
                                                          userInfo:info];
    }
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	NSLog(@"Failed to get token, error: %@", error);
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
