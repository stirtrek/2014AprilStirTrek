﻿using System.Collections.Generic;
using System.Linq;

namespace Rot13PushService
{
    public class DeviceRepository
    {
        protected DevicesEntities1 db = new DevicesEntities1();

        public void Add(string deviceIdentifier, string deviceOs)
        {
            if (!Exists(deviceIdentifier))
            {
                var device = new MobileDevice()
                    {
                        DeviceIdentifier = deviceIdentifier,
                        DeviceOs = deviceOs
                    };

                db.MobileDevices.Add(device);
                db.SaveChanges();
            }
        }

        public List<MobileDevice> List(string deviceOs)
        {
            var list = from md in db.MobileDevices
                       where md.DeviceOs == deviceOs
                       select md;

            return list.ToList();
        }

        public List<MobileDevice> ListAll()
        {
            var list = from md in db.MobileDevices
                       select md;

            return list.ToList();
        }

        public bool Exists(string deviceIdentifier)
        {
            var result = db.MobileDevices.Where(md => md.DeviceIdentifier == deviceIdentifier);

            return result.Any();
        }
    }
}