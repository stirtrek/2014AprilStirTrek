//
//  main.m
//  pushtalkrot13
//
//  Created by Peter Shearer on 3/22/14.
//  Copyright (c) 2014 Peter Shearer. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PTRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PTRAppDelegate class]));
    }
}
