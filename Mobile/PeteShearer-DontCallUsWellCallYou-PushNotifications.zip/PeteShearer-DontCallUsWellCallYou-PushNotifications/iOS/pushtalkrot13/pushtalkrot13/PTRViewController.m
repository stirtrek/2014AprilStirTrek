//
//  PTRViewController.m
//  pushtalkrot13
//
//  Created by Peter Shearer on 3/22/14.
//  Copyright (c) 2014 Peter Shearer. All rights reserved.
//

#import "PTRViewController.h"
#import "PTRConstants.h"

@interface PTRViewController ()

@property (weak, nonatomic) IBOutlet UILabel *resultLabel;
@property (weak, nonatomic) IBOutlet UITextField *inputText;
@property (weak, nonatomic) IBOutlet UIButton *encodeButton;
@property (weak, nonatomic) IBOutlet UIButton *pushButton;


@end

@implementation PTRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handlePushReceived:)
                                                     name:@"PushReceived"
                                                   object:nil];
    }
    return self;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)handlePushReceived:(NSNotification *)notification {
    NSString *message = notification.userInfo[@"PushMessage"];
    _inputText.text = message;
    NSString *plainText = _inputText.text;
    NSString *cipherText = [self rot13String:plainText];
    _resultLabel.text = cipherText;
}

- (IBAction)didPushEncodeButton:(UIButton *)sender {
    NSString *plainText = _inputText.text;
    NSString *cipherText = [self rot13String:plainText];
    _resultLabel.text = cipherText;
}
- (IBAction)didPushPushButton:(UIButton *)sender {
    NSString *baseUrl = @"%@/device/send/?message=%@";
    NSString *message = [_resultLabel.text stringByAddingPercentEscapesUsingEncoding: NSASCIIStringEncoding];
    NSString *url = [NSString stringWithFormat:baseUrl, [PTRConstants getServiceEndpoint], message];
    
    NSURLRequest * urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSURLResponse * response = nil;
    NSError * error = nil;
    NSData * data = [NSURLConnection sendSynchronousRequest:urlRequest
                                          returningResponse:&response
                                                      error:&error];
    
    if (error != nil)
    {
        NSLog(@"Failed to send, error: %@", error);
    }
    else
    {
        NSString *result = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"Send All Worked. We got this back: %@", result);
        _resultLabel.text = @"";
        _inputText.text = @"";
        UIAlertView *successAlert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                             message:@"Message Sent!"
                                                            delegate:nil
                                                   cancelButtonTitle:@"OK"
                                                   otherButtonTitles:nil];
        [successAlert show];
        successAlert = nil;
    }
}

// Slightly adapted from http://www.codecollector.net/view/4895/ROT13
-(NSString *) rot13String: (NSString *) input
{
	const char *_string = [input cStringUsingEncoding:NSASCIIStringEncoding];
	int stringLength = (int)[input length];
	char newString[stringLength+1];
    
	int x;
	for( x=0; x<stringLength; x++ )
	{
		unsigned int aCharacter = _string[x];
        
		if( 0x40 < aCharacter && aCharacter < 0x5B ) // A - Z
			newString[x] = (((aCharacter - 0x41) + 0x0D) % 0x1A) + 0x41;
		else if( 0x60 < aCharacter && aCharacter < 0x7B ) // a-z
			newString[x] = (((aCharacter - 0x61) + 0x0D) % 0x1A) + 0x61;
		else  // Not an alpha character
			newString[x] = aCharacter;
	}
    
	newString[x] = '\0';
    
	NSString *rotString = [NSString stringWithCString:newString encoding:NSASCIIStringEncoding];
	return( rotString );
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
